document.getElementById("login-form").addEventListener("submit", function(event) {
  // Form submission will redirect to home.html after successful validation
});